/*
 *This class is a subclass of  Contract class
 *Made to initialize the specific characteristics of mobile contracts
*/
package javaPhone;

/**
 *
 * @author meletis
 */
public class Mobile extends Contract {

  //initialize variables 
    private int sumOfFreeMB;
    private int sumOfFreeSMS;
 //make getters setters
    public int getSumOfFreeMB() {
        return sumOfFreeMB;
    }

    public void setSumOfFreeMB(int sumOfFreeMB) {
        this.sumOfFreeMB = sumOfFreeMB;
    }

    public int getSumOfFreeSMS() {
        return sumOfFreeSMS;
    }

    public void setSumOfFreeSMS(int sumOfFreeSMS) {
        this.sumOfFreeSMS = sumOfFreeSMS;
    }

}
