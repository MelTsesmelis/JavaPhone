/*
 *This class is a subclass of  Contract class
 *Made to initialize the specific characteristics of landline contracts
*/
package javaPhone;

/** 
 *
 * @author meletis tsesmelis (it219105)
 */
public class Landline extends Contract {

    //initialize variable 
    private int ADSLOrVDSL;
    //make getter setter
    public int getAdslOrVdsl() {
        return ADSLOrVDSL;
    }

    public void setAdslOrVdsl(int ADSLOrVDSL) {
        this.ADSLOrVDSL = ADSLOrVDSL;
    }

}
