/*
 * This class made to initialize the characteristics  of a contract.
 * Use localDataTime and Random().
*/

package javaPhone;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Random;

/**
 *
 * @author meletis tsesmelis (it210105)
 */
public class Contract {

    //initialize variables
    private int contractNumber;
    private int minsOfFreeCalls;
    private int duration;
    private int monthlyCost;
    private int eAccountOrNot;
    private int methodOfPayment;
    private BigInteger phone;
    private int totalDiscounds;
    private int discoundsStatus,disoundsPayment,discoundsFreeCalls,discoundsEAccount,discoundsPerContract;
     //use random to make contractID
    Random rdm = new Random();
     //initialize local date time
    private LocalDateTime ldt;
    
    public LocalDateTime getLdt() {
        return ldt;
    }

    //make getter setters for them 
    public int getDiscoundsPerContract() {
        return discoundsPerContract;
    }

    public void setDiscoundsPerContract(int discoundsPerContract) {
        this.discoundsPerContract = discoundsPerContract;
    }

    public int getDiscoundsEAccount() {
        return discoundsEAccount;
    }

    public void setDiscoundsEAccount(int discoundsEAccount) {
        this.discoundsEAccount = discoundsEAccount;
    }

    public int getDiscoundsStatus() {
        return discoundsStatus;
    }

    public void setDiscoundsStatus(int discoundsStatus) {
        this.discoundsStatus = discoundsStatus;
    }

    public int getDisoundsPayment() {
        return disoundsPayment;
    }

    public void setDisoundsPayment(int disoundsPayment) {
        this.disoundsPayment = disoundsPayment;
    }

    public int getDiscoundsFreeCalls() {
        return discoundsFreeCalls;
    }

    public void setDiscoundsFreeCalls(int discoundsFreeCalls) {
        this.discoundsFreeCalls = discoundsFreeCalls;
    }
    
    public int getTotalDiscounds() {
        return totalDiscounds;
    }

    public void setTotalDiscounds(int totalDiscounds) {
        this.totalDiscounds = totalDiscounds;
    } 

    public void setLdt(LocalDateTime ldt) {
        this.ldt = ldt;
    }
   

    //make getters setters
    public int getContractID() {
        return contractNumber;
    }

    public void setContractNumber() {
        this.contractNumber = rdm.nextInt(17);
    }

    public BigInteger getPhone() {
        return phone;
    }

    public void setPhone(BigInteger phone) {
        this.phone = phone;
    }

    public int getMinsOfFreeCalls() {
        return minsOfFreeCalls;
    }

    public void setMinsOfFreeCalls(int MinsOfFreeCalls) {
        this.minsOfFreeCalls = MinsOfFreeCalls;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getMonthlyCost() {
        return monthlyCost;
    }

    public void setMonthlyCost(int monthlyCost) {
        this.monthlyCost = monthlyCost;
    }

    public int geteAccountOrNot() {
        return eAccountOrNot;
    }

    public void seteAccountOrNot(int eAccountOrNot) {
        this.eAccountOrNot = eAccountOrNot;
    }

    public int getMethodOfPayment() {
        return methodOfPayment;
    }

    public void setMethodOfPayment(int methodOfPayment) {
        this.methodOfPayment = methodOfPayment;
    }

}
