/*
 * This class made to implements all methods that we need for this program.
 * 
*/
package javaPhone; 

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

public class Methods {      
    public static ArrayList<Customer> listOfCustomers = new ArrayList<>();
    
   public void myCustomers(){
         //MAKE 3 DEFAULT-CUSTOMERS, SO YOU CAN START WITH ANY OPTIONS IN MENU (ADD CONTRACT - DELETE...)
                                              // vat       address    identity,status , email  
         Customer testCustomer1 = new Customer(123456789,"papaflesas_7",123456,3,"makiskatsaneas@gmail.com");
         Customer testCustomer2 = new Customer(123456798,"dhmhtros_27",123465,3,"vagelisorganidhs@gmail.com");
         Customer testCustomer3 = new Customer(456123789,"kati",147258,2,"kati@hotmail.gr");
         //BASED IN OUR PACKETS-OPTIONS
           //CREATE A LANDLINE  CONTRACT FOR FIRST DEFAULT-CUSTOMER
         Landline c1Landline = new Landline();
         c1Landline.setDuration(24);
         c1Landline.setMethodOfPayment(1);
         c1Landline.setMinsOfFreeCalls(1800);
         c1Landline.setMonthlyCost(15);
         c1Landline.setPhone(BigInteger.valueOf(2105557338));//long type can take this number
         c1Landline.seteAccountOrNot(1);
         c1Landline.setContractNumber();
         c1Landline.setLdt(LocalDateTime.of(2021,1,4,3,2,1));
         c1Landline.setAdslOrVdsl(1);
         testCustomer1.listOfContracts.add(c1Landline);//add in list of contracts 
         
         //CREATE A MOBILE CONTRACT FOR FIRST DEFAULT CUSTOMER
         Mobile c1Mobile = new Mobile();
         c1Mobile.setDuration(12);
         c1Mobile.setMethodOfPayment(2);
         c1Mobile.setMinsOfFreeCalls(1200);
         c1Mobile.setMonthlyCost(24);
         BigInteger number1 = new BigInteger("6988245862"); //i have to use this , cause this number is out of long`s range
         c1Mobile.setPhone(number1);
         c1Mobile.seteAccountOrNot(1);
         c1Mobile.setContractNumber();
         c1Mobile.setLdt(LocalDateTime.of(2021,1,4,3,2,1));
         c1Mobile.setSumOfFreeMB(20000);
         c1Mobile.setSumOfFreeSMS(100);
         testCustomer1.listOfContracts.add(c1Mobile); //add in list of contracts
                  
         
            //CREATE A LANDLINE  CONTRACT FOR SECOND DEFAULT-CUSTOMER
         Landline c2Landline = new Landline();
         c2Landline.setDuration(12);
         c2Landline.setMethodOfPayment(3);
         c2Landline.setMinsOfFreeCalls(600);
         c2Landline.setMonthlyCost(6);
         c2Landline.setPhone(BigInteger.valueOf(2105557339));//long type can take this number
         c2Landline.seteAccountOrNot(1);
         c2Landline.setContractNumber();
         c2Landline.setLdt(LocalDateTime.of(2021,1,6,3,8,6));
         c2Landline.setAdslOrVdsl(0);
         testCustomer2.listOfContracts.add(c2Landline);//add in list of contracts 
         
         //CREATE A MOBILE CONTRACT FOR SECOND DEFAULT CUSTOMER
         Mobile c2Mobile = new Mobile();
         c2Mobile.setDuration(24);
         c2Mobile.setMethodOfPayment(1);
         c2Mobile.setMinsOfFreeCalls(900);
         c2Mobile.setMonthlyCost(8);
         BigInteger number2 = new BigInteger("6988245863"); //i have to use this , cause this number is out of long`s range
         c2Mobile.setPhone(number2);
         c2Mobile.seteAccountOrNot(0);
         c2Mobile.setContractNumber();
         c2Mobile.setLdt(LocalDateTime.of(2021,1,6,5,4,3));
         c2Mobile.setSumOfFreeMB(0);
         c2Mobile.setSumOfFreeSMS(0);
         testCustomer2.listOfContracts.add(c2Mobile); //add in list of contracts
         
         //CREATE A LANDLINE  CONTRACT FOR THIRD DEFAULT-CUSTOMER
         Landline c3Landline = new Landline();
         c3Landline.setDuration(24);
         c3Landline.setMethodOfPayment(2);
         c3Landline.setMinsOfFreeCalls(800);
         c3Landline.setMonthlyCost(10);
         c3Landline.setPhone(BigInteger.valueOf(2105557340));//long type can take this number
         c3Landline.seteAccountOrNot(0);
         c3Landline.setContractNumber();
         c3Landline.setLdt(LocalDateTime.of(2021,4,6,3,8,6)); //so its not active now (31-1-2021)
         c3Landline.setAdslOrVdsl(1);
         testCustomer3.listOfContracts.add(c3Landline);//add in list of contracts 
         
         //CREATE A MOBILE CONTRACT FOR THIRD DEFAULT CUSTOMER
         Mobile c3Mobile = new Mobile();
         c3Mobile.setDuration(24);
         c3Mobile.setMethodOfPayment(1);
         c3Mobile.setMinsOfFreeCalls(1800);
         c3Mobile.setMonthlyCost(15);
         BigInteger number3 = new BigInteger("6988245864"); //i have to use this , cause this number is out of long`s range
         c3Mobile.setPhone(number3);
         c3Mobile.seteAccountOrNot(1);
         c3Mobile.setContractNumber();
         c3Mobile.setLdt(LocalDateTime.of(2021,5,6,5,4,3)); //so its not active now (31-1-2021)
         c3Mobile.setSumOfFreeMB(500);
         c3Mobile.setSumOfFreeSMS(200);
         testCustomer3.listOfContracts.add(c3Mobile); //add in list of contracts
         
         //add them in list of customers 
         listOfCustomers.add(testCustomer1);
         listOfCustomers.add(testCustomer2);
         listOfCustomers.add(testCustomer3);
   }
   
    public void menu() {   //CREATE THE BASIC MENU WITH OPTIONS
        System.out.println("\nHow can I help you?\n"
                + "\t1.Press '1' if you want to add a profile.\n"
                + "\t2.Press '2' if you want to add a new contract.\n"
                + "\t3.Press '3' if you want to delete a contract.\n"
                + "\t4.Press '4' if you want to see informations of your contracts.\n"
                + "\t5.Press '5' if you want to exit of the program\n");  
    }
    
    //METHOD TO FIND AN CUSTOMER WITH HIS VAT AND IDENTITY NUMBER
    public Customer findCustomer(int vat,int identity){
        for(int i=0;i<listOfCustomers.size();i++){
            if (vat==listOfCustomers.get(i).getVAT()){
               if (listOfCustomers.get(i).getIdentity()==identity){                                                      
                   return listOfCustomers.get(i);
               }
            } 
        } 
        return null;
    }
    //METHOD TO FIND AN CUSTOMER WITH ONLY HIS VAT
    public Customer findCustomer(int vat){
        for(int i=0;i<listOfCustomers.size();i++){
            if (vat==listOfCustomers.get(i).getVAT())
                   return listOfCustomers.get(i); 
        } 
        return null;
    }
    //ADD A PROFILE 
    public void toImportCustomerProfile()
    {
        Customer cust = new Customer();
        Scanner s = new Scanner(System.in);
        
        //ASK FOR HIS VAT
        System.out.println("\tPlease give me your VAT");//9-digit number (greece)
        int vat = s.nextInt();
        while(vat<=99999999 || vat>999999999){ //so  8 or 10 digit number given
            System.out.println("\tCheck it again!Remember its an 9-digit number");
            vat = s.nextInt();
        }
        cust.setVAT(vat);
        
        //USE RANDOM() TO MAKE AND PUT CUSTOMER ID 
        cust.setCustomerID();
        int numberOfCustomer=cust.getIdCustomer();
       
        //ASK FOR HIS IDENTITY NUMBER (WITHOUT "AM" - ONLY 6DIGIT NUMBER)
        System.out.println("\tPlease give me your identity number");
        int identity = s.nextInt();
        while (identity<=99999||identity>999999) //identity number has 6 digits in greece
        {
            System.out.println("\tCheck again!Identity number has 6 digit!");
            identity = s.nextInt();
        }
        cust.setIdentity(identity);
        
        //CHECK IF WE HAVE ALREADY THIS USER, IN CASE THIS IS TRUE,GO BACK ON MENU
        Customer check= findCustomer(vat,identity);
        if (check!=null){
            System.out.println("\tWe have already this user!");
            return;
        }   
        
        //ASK FOR HIS ADDRESS
        System.out.println("\tPlease give me your address (like \"papapetrou_46\" in other case we will ignore the number)");
        String address = s.next();
        cust.setCustomerAddress(address);
   
        //ASK FOR HIS STATUS
        System.out.println("\nPlease give me your status \n"
                + "\t*press '1' if you are Student\n"
                + "\t*press '2' if you are individual\n" //=ιδιώτης 
                + "\t*press '3' if you are professional");
        int status = s.nextInt();
        switch(status){
            case 1:
                System.out.println("\tSo you are student!\n");
                break;
            case 2:
                System.out.println("\tSo you are individual!\n");
                break;
            case 3:
                System.out.println("\tWow you are professional!\n");
                break;
            default:
                while(status<1 && status>3){
                    System.out.println("\tSorry I asked an integer number between 1 and 3!Let\'s try again!");
                    status=s.nextInt();
                }
                if(status==2||status==1) System.out.println("\tGreat!"); //otherwise buffer with wrong input there will print that 
                break;
        }  
        cust.setCustomerStatus(status);

        //ASK FOR HIS EMAIL
        System.out.println("\tPlease give me your email");
        String email = s.next();
        if ( (!email.contains("@")) || (!email.contains(".")) ){
            do{
                System.out.println("\tUnacceptable type of email!We need something like it219105@hua.gr");
                email = s.next();
                
            }while(!(email.contains("@") && email.contains(".")));
        
        }
        cust.setEmail(email);
        
        //PRINT ALL THOSE INFORMATIONS
        System.out.println("\nYour customer ID is: "+numberOfCustomer+
                           "\nGiven VAT:\t      " + cust.getVAT()+
                           "\nGiven identity:      " + cust.getIdentity() 
                          +"\nGiven address:\t      " + cust.getCustomerAddress()+ 
                           "\nGiven status:\t      "+ printStatus(cust.getCustomerStatus()) 
                          +"\nGiven Email:\t      "+cust.getEmail()
                           +"\nTotal Discounds:     0%"); //because he hasn`t any contract right now (we are on profile-maker)
        //ADD HIM IN LIST OF CUSTOMERS
     listOfCustomers.add(cust);
       
        
    }
      
    
    
    //ADD A CONTRACT
    public void toIntroductionNewContract() { 
        //Make a scanner, to use this and take input by user
        Scanner s1 = new Scanner(System.in);
        
        //ask user what kind of contract wants to
        System.out.println("\tDo you need landline or mobile?\n"
                + "\t *Press '1' if you want landline.\n"
                + "\t *Press '2' if you want mobile.\n");
        int answer;
        int sum=1;
        do{
            if(sum!=1){
                System.out.println("\tI asked an integer number between 1 and 2!Try again!");
            }
                answer = s1.nextInt();
            sum++;
        }while(answer==1 && answer==2);
        
        
        
        switch (answer) {
            case 1://LANDLINE CONTRACT
                System.out.println("\tLet\'s create an landline!\n");
                Landline landline = new Landline();
                Scanner x = new Scanner(System.in); //I could skip that, i have already one, but something went wrong with buffer,and when i created that worked so i keep it 
                
                //ASK FOR HIS VAT
                System.out.println("\tPlease give me your vat");
                int vatL=x.nextInt();
                 while(vatL<=99999999 || vatL>999999999){ //so  8 or 10 digit number given
                   System.out.println("\tCheck it again!Remember its an 9-digit number ");
                    vatL = x.nextInt();
                 }
                 
                 //PUT CONTRACT NUMBER
                 landline.setContractNumber();
                 int numberOfContractL=landline.getContractID(); // put a random number and save it us number of this contract
                
                System.out.println("\tPlease give me your identity number");
                int identityL=x.nextInt();
                while (identityL<=99999||identityL>999999) //identity number has 6 digits in greece
                {
                      System.out.println("\tCheck again!Identity number has 6 digit!");
                      identityL = x.nextInt();
                }
                //MAKE A CUSTOMER TO CHECK IF THIS ONE HAVE A PROFILE OR HE HAS TO MAKE ONE FIRST
                Customer customer= new Customer();
                customer= findCustomer(vatL,identityL);
                
                //CHECK IF THIS PROFILE EXISTS , IF NOT STOP THE PROGRAM
                if (customer==null){
                    System.out.println("\tYou have to make a profile first!and then come again for your contract!");
                    return;
                }
                
                //ASK FOR HIS LANDLINE  NUMBER 
                System.out.println("\tPlease give me your number");
                BigInteger tmpL=new BigInteger(x.next());
                BigInteger downLimitL=new BigInteger("999999999");//more than 9-digits
                BigInteger upLimitL=new BigInteger("99999999999"); //less than 11-digits
                
                Boolean checkL=tmpL.toString().startsWith("2");
                //compare to  returns   -1 for < , 0 for == , 1 for >                so no starts with "2"
                while( tmpL.compareTo(downLimitL)==-1 || tmpL.compareTo(upLimitL)==1 || checkL==false ){
                    if(tmpL.compareTo(downLimitL)==-1 || tmpL.compareTo(upLimitL)==1)
                     System.out.println("\tCheck it again!We need an 10-digit number"); // 10-digit phones in greece

                    //so its false, this number don`t starts with 2
                    if(!checkL) 
                     System.out.println("\tLandline have to start with 2");
                    
                    tmpL=new BigInteger(x.next());
                    checkL =tmpL.toString().startsWith("2");
                }
                
               
                
                  //CHECK IF ANOTHER CUSTOMER HAS THE SAME PHONE IN OTHER CONTRACT
                 for(int i=0; i<listOfCustomers.size() ;i++){
                     for(int j=0; j<listOfCustomers.get(i).listOfContracts.size();j++){
                             if(!listOfCustomers.get(i).listOfContracts.isEmpty()){
                                 if(listOfCustomers.get(i).listOfContracts.get(i).getPhone().compareTo(tmpL)==0 && listOfCustomers.get(i).getVAT()!=vatL){
                                        System.out.println("\tanother customer has the same phone in a contract!");
                                        return;
                                    } 
                                }
                        }   
                   }
                landline.setPhone(tmpL);
                
                
               //GIVE THE DATE THAT HE WANTS START THE CONTRACT
                int run=0;
                int year;
                int month;
                int day;
                int hour;
                int minute;
                int second;
                Scanner k = new Scanner(System.in);
                 int yearNow=LocalDateTime.now().getYear();
              do{ //CHECK EACH ARGUMENT TO TAKE A REASONABLE VARIABLE VALUE
                     System.out.println("\tGive me the date that you want start the contract!");
                     System.out.println("\tYear");
                        year= k.nextInt();
                        while(year<yearNow){
                            System.out.println("Travel in past is not possible yet! Try again!");
                            year= k.nextInt();
                        }
                     System.out.println("\tMonth");
                        month= k.nextInt();
                        while(month<1||month>12){
                            System.out.println("We have 12 months! You have to write '1' -> January , '2' -> frebruary,...Try again!");
                             month= k.nextInt();
                        }
                     System.out.println("\tDay");
                        day= k.nextInt();
                        while(day<1||day>31){
                            System.out.println("Months cannot have more than 31 or less than 1 day!Try again!");
                            day= k.nextInt();
                        }
                     System.out.println("\tHour");
                        hour=k.nextInt();
                        while(hour<0||hour>23){
                            System.out.println("A day has 24 hours!!Try again!");
                            hour=k.nextInt();
                        }
                     System.out.println("\tMinute");
                        minute=k.nextInt();
                        while(minute<0||minute>59){
                            System.out.println("An hour has 60 min!Try again!");
                            minute=k.nextInt();
                        }
                     System.out.println("\tSecond");
                        second=k.nextInt();
                        while(second<0||second>59){
                            System.out.println("A minute has 60 seconds!Try again!");
                            second=k.nextInt();
                        }
                     LocalDateTime ldt=LocalDateTime.of(year,month, day,hour,minute,second);
                     LocalDateTime now=LocalDateTime.now();
                     
                 //THEN CHECK IF GIVEN DATE IS ACCEPTABLE AND IF IS THEN CHECK IF WE HAVE OTHER ACTIVE CONTRACT ON THIS TIME AT THE SAME NUMBER 
                for (int i = 0; i <  customer.listOfContracts.size(); i++) {
                    if(customer.listOfContracts.get(i).getPhone().equals(tmpL)){   
                        if(ldt.isBefore(now)){
                            System.out.println("\tTravel in past is not possible yet! Make sure about your date");
                            //CHECK IF ANOTHER CONTRACT IS ACTIVE WITH THAT NUMBER 
                        }else if(!ldt.isAfter(customer.listOfContracts.get(i).getLdt().plusMonths(customer.listOfContracts.get(i).getDuration() ))){
                            System.out.println("You cannot active 2 contracts at the same time with the same number!");
                            return;
                        }else{
                           run=1;     //if not then go out of loop, keep going in other code    
                        }
                    }
               }
               }while(run==1);
              
               //LIST OF PACKAGES OPTIONS 
                System.out.println("\nPress\n"
                        + "* '1' and take  600min for landline phone numbers with 6euros/month\n"
                        + "* '2' and take  500min for landline phones and 300min for mobiles with 10euros/month\n"
                        + "* '3' and take  1200min for landline phones, 600min for mobiles   with 15euros/month\n"
                        + "* '4' and take  3000min for all  with 25euros/month");
                
                int ans = x.nextInt();
                String option="ERROR";
                switch(ans){ //SAVE WHAT IT NEEDS WITH THIS OPTION 
                    case 1:
                        option ="600min for landline with 6euros/month";
                        landline.setMinsOfFreeCalls(600);
                        landline.setMonthlyCost(6);
                    break;
                    case 2:
                        option ="500min for landline phones and 300min for mobiles with 10euros/month";
                        landline.setMinsOfFreeCalls(500);
                        landline.setMonthlyCost(10);
                    break;
                    case 3:
                        option ="1200min for landline phones, 600min for mobiles   with 15euros/month";
                        landline.setMinsOfFreeCalls(1200);
                        landline.setMonthlyCost(15);
                    break;
                    case 4:
                        option ="3000min for all  with 25euros/month";
                        landline.setMinsOfFreeCalls(3000);
                        landline.setMonthlyCost(25);
                    break;
                    default:
                        System.out.println("\twrong input,try again!");
                        
                }
                //ASK FOR ADSL OR VDSL LINE 
                System.out.println("\tPlease press '1' if you want ADSL or '2' if you want VDSL");
                int answerr =x.nextInt();
                while(answerr!=1 && answerr!=2){
                    System.out.println("\tLet\'s try again!Press '1'->ADSL or '2'->VDSL");
                    answerr =x.nextInt();
                }
                landline.setAdslOrVdsl(answerr);
                
                //ASK FOR DURATION 
                System.out.println("\tPlease give me the duration of contract(12 or 24months)");
                int durationL=x.nextInt();
                  while (!(durationL==24 || durationL==12)){
                      System.out.println("\tyou have to write '12' or '24' ");
                      durationL=x.nextInt();
                  }
                  landline.setDuration(durationL);
                  
                  //ASK IF HE WANTS E-ACCOUNT OR NOT 
                System.out.println("\tIf you want e-account press '1' otherwise press '0'");
                int eAccountOrNotL = x.nextInt();
                while (eAccountOrNotL!=1 && eAccountOrNotL!=0){
                    System.out.println("\tPlease write '0'(no e-account) or '1' (e-account)");
                    eAccountOrNotL = x.nextInt();
                }
                landline.seteAccountOrNot(eAccountOrNotL);
                
                //ASK FOR PAYMENT-METHOD 
                System.out.println("\tIf you want to pay with\n"
                        + "\t *credit card press '1'\n"
                        + "\t *cash press '2'\n"
                        + "\t *in a bank account press '3'");
                int method=x.nextInt();
                while(method<1 && method>3){
                    System.out.println("\tCheck again!Press 1-> credit 2-> cash 3-> bank account");
                    method=x.nextInt();
                }
                landline.setMethodOfPayment(method);  
                
                //PRINT THOSE INFORMATIONS 
                System.out.println("\nYour contract ID is: " +numberOfContractL+
                                   "\nType:\t\t      " + printType(landline.getPhone())+
                                   "\nMethod:\t\t      " + printMethodOfPayment(method) 
                                  +"\nNumber:\t\t      " + landline.getPhone()+
                                   "\noption:\t\t      " + option+
                                   "\nDuration:\t      "+printDuration(landline.getDuration())+
                                   "\ne-account:\t      "+printEAccount(landline.geteAccountOrNot())
                                  +"\nline:\t\t      "+printAdslOrVdsl(landline.getAdslOrVdsl()));
                break;
           
            case 2://MOBILE CONTRACT 
                System.out.println("\tLet\'s create an mobile!\n");
                Mobile mobile = new Mobile();
                Scanner y = new Scanner(System.in);
                
                
                //ASK FOR HIS VAT 
                System.out.println("\tPlease give me your vat");
                int vatM=y.nextInt();
                while(vatM<=99999999 || vatM>999999999){ //so  8 or 10 digit number given
                   System.out.println("\tCheck it again!Remember its an 9-digit number ");
                   vatM = y.nextInt();
                }
                
                //ASK FOR HIS IDENTITY 
                System.out.println("\tPlease give me your identity number");
                int identityM=y.nextInt();
                while (identityM<=99999||identityM>999999) //identity number has 6 digits in greece
                {
                      System.out.println("\tCheck again!Identity number has 6 digit!");
                      identityM = y.nextInt();
                }
                //MAKE A CUSTOMER TO CHECK IF HE HAS A PROFILE OR HE HAS TO MAKE ONE FIRST 
                Customer customerM= new Customer();
                customerM= findCustomer(vatM,identityM); 
                if (customerM==null){
                    System.out.println("\tYou have to make a profile first!and then come again for your contract!");
                    return;
                }
                
                //ASK FOR HIS NUMBER
                System.out.println("\n\tPlease give me your number");
                BigInteger tmpM=new BigInteger(y.next());
                BigInteger downLimitM=new BigInteger("999999999");//more than 9-digits
                BigInteger upLimitM=new BigInteger("99999999999"); //less than 11-digits
                
                Boolean checkM =tmpM.toString().startsWith("69");
                //compare to  returns   -1 for < , 0 for == , 1 for >                so no starts with "2"
                while( tmpM.compareTo(downLimitM)==-1 || tmpM.compareTo(upLimitM)==1 || checkM==false ){
                    if(tmpM.compareTo(downLimitM)==-1 || tmpM.compareTo(upLimitM)==1)
                     System.out.println("\tCheck it again!We need an 10-digit number"); // 10-digit phones in greece
                    //so its false, this number don`t starts with 2
                    if(!checkM) System.out.println("\tMobile has to start with 69");
                    
                    tmpM=new BigInteger(y.next());
                    checkM =tmpM.toString().startsWith("69");
                }
                
                
                //ckeck if another customer has the same phone
                 for(int i=0; i<listOfCustomers.size() ;i++){
                     for(int j=0; j<listOfCustomers.get(i).listOfContracts.size();j++){
                             if(! listOfCustomers.get(i).listOfContracts.isEmpty()){
                                 if(listOfCustomers.get(i).listOfContracts.get(j).getPhone().compareTo(tmpM)==0 && listOfCustomers.get(i).getVAT()!=vatM){
                                        System.out.println("\tanother customer has the same phone in a contract!");
                                        return;
                                    } 
                                }
                        }   
                   }
                 
                mobile.setPhone(tmpM);           
               
                mobile.setContractNumber();
                 int numberOfContractM=mobile.getContractID(); // put a random number and save it us number of this contract

                run=0;
                Scanner m = new Scanner(System.in);
                 int yearNowM=LocalDateTime.now().getYear(); //GET CURRENT YEAR OF SYSTEM 
              do{// TAKE DATE THAT HE WANTS TO START THIS CONTRACT 
                     System.out.println("\tGive me the date that you want start the contract!");
                     System.out.println("\tYear");
                        year= m.nextInt();
                        while(year<yearNowM){
                            System.out.println("Travel in past is not possible yet! Try again!");
                            year= m.nextInt();
                        }
                     System.out.println("\tMonth");
                        month= m.nextInt();
                        while(month<1||month>12){
                            System.out.println("We have 12 months! You have to write '1' -> January , '2' -> frebruary,...Try again!");
                             month= m.nextInt();
                        }
                     System.out.println("\tDay");
                        day= m.nextInt();
                        while(day<1||day>31){
                            System.out.println("Months cannot have more than 31 or less than 1 day!Try again!");
                            day= m.nextInt();
                        }
                     System.out.println("\tHour");
                        hour=m.nextInt();
                        while(hour<0||hour>23){
                            System.out.println("A day has 24 hours!!Try again!");
                            hour=m.nextInt();
                        }
                     System.out.println("\tMinute");
                        minute=m.nextInt();
                        while(minute<0||minute>59){
                            System.out.println("An hour has 60 min!Try again!");
                            minute=m.nextInt();
                        }
                     System.out.println("\tSecond");
                        second=m.nextInt();
                        while(second<0||second>59){
                            System.out.println("A minute has 60 seconds!Try again!");
                            second=m.nextInt();
                        }
                     LocalDateTime ldt=LocalDateTime.of(year,month, day,hour,minute,second);
                     LocalDateTime now=LocalDateTime.now();
                     
                     
                     //CHECK IF THAT DATE IS ACCEPTABLE, AND IF ANOTHER CONTRACT IS ACTIVE ON THAT DATE (until duration ends)
                for (int i = 0; i <  customerM.listOfContracts.size(); i++) {
                    if(customerM.listOfContracts.get(i).getPhone().equals(tmpM)){   
                        if(ldt.isBefore(now)){
                            System.out.println("\tTravel in past is not possible yet! Make sure about your date");            
                        }else if(!ldt.isAfter(customerM.listOfContracts.get(i).getLdt().plusMonths(customerM.listOfContracts.get(i).getDuration() ))){
                            System.out.println("You cannot active 2 contracts at the same time with the same number!");
                            return;
                        }else{
                           run=1;        
                        }
                    }
               }
               }while(run==1);
              
              //TAKE THE DURATION OF THE CONTRACT 
                System.out.println("\tPlease give me the duration of contract(12 or 24months)");
                int durationM=y.nextInt();
                  while (!(durationM==24 || durationM==12)){
                      System.out.println("\tyou have to write '12' or '24'months for duration ");
                      durationM=y.nextInt();
                  }
                  mobile.setDuration(durationM);
                
                  //ASK IF HE WANTS E-ACCOUNT OR NOT 
                System.out.println("\tIf you want e-account press '1' otherwise press '0'");
                int eAccountOrNotM = y.nextInt();
                while (eAccountOrNotM!=1 && eAccountOrNotM!=0){
                    System.out.println("\tPlease write '0'(no e-account) or '1' (e-account)");
                    eAccountOrNotM = y.nextInt();
                }
                mobile.seteAccountOrNot(eAccountOrNotM);                
                
                //ASK FOR PAYMENT-METHOD
                System.out.println("\tIf you want to pay with\n"
                        + "\t*credit card press '1'\n"
                        + "\t*cash press '2'\n"
                        + "\t*in a bank account press '3'");
                int methodM=y.nextInt();
                while(methodM<1 && methodM>3){
                    System.out.println("\tCheck again!Press 1-> credit 2-> cash 3-> bank account");
                    methodM=y.nextInt();
                }    
                mobile.setMethodOfPayment(methodM);
                
                //LIST OF PACKAGE OPTIONS
                System.out.println("\n\tPress\n"
                        + "\t* '1' and take  600min for landline phone numbers and 300min for mobiles  with 8euros/month\n"
                        + "\t* '2' and take  1200min for landline phones and 300min for mobiles with 12euros/month\n"
                        + "\t* '3' and take  1200min for landline phones, 600min, 500mb for mobiles and 200sms for all   with 15euros/month\n"
                        + "\t* '4' and take  2000min for all,1200min for mobiles, 5GB, 100sms for all with 20euros/month\n"
                        + "\t* '5' and take  20GB,1200min for all,100 sms for all with 24euros/month");  
                
                int ansM = y.nextInt();
                String optionM="Error in option!";
                switch(ansM){
                    case 1: 
                        optionM ="600min for landline phone numbers and 300min for mobiles  with 8euros/month";
                        mobile.setMinsOfFreeCalls(900);
                        mobile.setMonthlyCost(8);
                        mobile.setSumOfFreeSMS(0);
                        mobile.setSumOfFreeMB(0);
                    break;
                     
                    case 2:
                        optionM ="1200min for landline phones and 300min for mobiles with 12euros/month";
                        mobile.setMinsOfFreeCalls(1500);
                        mobile.setMonthlyCost(12);
                        mobile.setSumOfFreeSMS(0);
                        mobile.setSumOfFreeMB(0);
                    break;
                    case 3:
                        optionM ="1200min for landline phones, 600min for mobiles,500mb and 200sms for all   with 15euros/month";
                        mobile.setMinsOfFreeCalls(1800);
                        mobile.setMonthlyCost(15);
                        mobile.setSumOfFreeSMS(200);
                        mobile.setSumOfFreeMB(500);
                    break;
                    case 4:
                        optionM ="2000min for all,1200min for mobiles, 5GB, 100sms for all with 20euros/month";
                        mobile.setMinsOfFreeCalls(3200);
                        mobile.setMonthlyCost(20);
                        mobile.setSumOfFreeSMS(100);
                        mobile.setSumOfFreeMB(5000);
                    break;
                    
                    case 5:
                        optionM = "20GB,1200min for all,100 sms for all with 24euros/month";
                        mobile.setMinsOfFreeCalls(1200);
                        mobile.setMonthlyCost(24);
                        mobile.setSumOfFreeSMS(100);
                        mobile.setSumOfFreeMB(20000);
                    break;
                    default:
                        System.out.println("wrong input,try again!");
                    break;
                }      //PRINT THOSE INFORMATIONS 
                      System.out.println("\nYour contract ID is: " +numberOfContractM+
                                   "\nType:\t\t      " + printType(mobile.getPhone())+
                                   "\nMethod:\t\t      " + printMethodOfPayment(methodM) 
                                  +"\nNumber:\t\t      " + mobile.getPhone()+
                                   "\noption:\t\t      " + optionM+
                                   "\nDuration:\t      "+printDuration(mobile.getDuration())+
                                   "\ne-account:\t      "+printEAccount(mobile.geteAccountOrNot()));  
            break;
        }
    }

    public void toDeleteContract() {//DELETATION OF A CONTRACT 
        //ASK FOR HIS VAT
        System.out.println("Give us your vat, to print you back your contracts");
        Customer cust = new Customer();
        Scanner y = new Scanner(System.in);
        int vat=y.nextInt();
        while(vat<=99999999 || vat>999999999){ //so  8 or 10 digit number given
                   System.out.println("\tCheck it again!Remember its an 9-digit number ");
                   vat = y.nextInt();
                }
        cust=findCustomer(vat);
        
        if(cust==null){
            System.out.println("\tWe don`t have that user!");
            return;
        }
        
        //CHECK IF LIST OF CONTRACTS IS EMPTY 
       if(cust.listOfContracts.isEmpty()){
            System.out.println("List of Contracts is empty!");
            return;
        }  
       int cNumber=0;
       // IF NOT PRINT THEM ON AN "ARRAY"
        System.out.println("\nnumber phone      type     startDate            duration");
        for(int index=1;index<cust.listOfContracts.size()+1 ;index++){
              if ("mobile".equals(printType(cust.listOfContracts.get(index-1).getPhone())))
                   System.out.println("  "+index+"    "+cust.listOfContracts.get(index-1).getPhone()+" "+ printType(cust.listOfContracts.get(index-1).getPhone())+"   "+cust.listOfContracts.get(index-1).getLdt()+"  "+printDuration(cust.listOfContracts.get(index-1).getDuration()));
               if ("landline".equals(printType(cust.listOfContracts.get(index-1).getPhone())))
                   System.out.println("  "+index+"    "+cust.listOfContracts.get(index-1).getPhone()+" "+ printType(cust.listOfContracts.get(index-1).getPhone())+" "+cust.listOfContracts.get(index-1).getLdt()+"  "+printDuration(cust.listOfContracts.get(index-1).getDuration()));
          
               if(!cust.listOfContracts.isEmpty()){
                       cNumber=1;   
               }
             
        }
        
        //ASK FOR THE NUMBER OF OPTIONS TO DELETE THAT CONTRACT 
        System.out.println("\nGive us the number of contract to delete\n"
                + "for example if you want delete first write '1', seconde '2'...");
         int number=y.nextInt();
         if(number!=1 ||number!=2){
             while(number!=1&& number!=2){
                 System.out.println("Please enter the number between '"+cNumber+"' and '"+cust.listOfContracts.size()+"'");
                 number=y.nextInt();
             }
         }
         
         //CHECK DELETATION
        if (deleteContract(number,cust)){
            System.out.println("We deleted this contract!");
        }else{
            System.out.println("We had unknown problem on deletion,try again!");
        }  
    }
    
     //TAKE US ARGUMENT THE CUSTOMER, AND HIS OPTION (THE NUMBER)AND DELETE THAT CONTRACT
     private boolean deleteContract(int number,Customer cust){
        //check if this Customer has any contract
        if (cust.listOfContracts==null){
            System.out.println("You don`t have any contract!");
            return false;
        }
        cust.listOfContracts.remove(number-1);  //because index==number of list -1
        return true;
    }
    
    public void toSeeStatisticsOfActiveContracts() 
    {
        //todo 
        Scanner y = new Scanner(System.in);
        Customer cust =new Customer();
        System.out.println("If you want:\n"
                + "\t*to see statistics preferences of customers press 1\n"
                + "\t*to see details about your active contracts press 2\n"
                + "\t*to see total discound of your contracts press 3\n");
         int option;
         int times=1;
        do{
        option=y.nextInt();
        if(times++>1) System.out.println("\tYou have to put 1,2 or 3. Try again!");
        }while(option!=1&&option!=2&&option!=3);
        
        switch (option) 
        {
          case 1://see statistics 
            System.out.println("\t>If you want to see statistics of customers for free calls option press '1'\n"
                              +"\t>If you want to see statistics of customers for sms press '2'\n"
                              +"\t>If you want to see statistics of customers for MB press'3'\n");
                    times=1;
                    int opt;
                    do{
                          opt=y.nextInt();
                          if(times++>1) System.out.println("\tYou have to put 1,2 or 3. Try again!");
                    }while(opt!=1&&opt!=2&&opt!=3); 
                    switch(opt)
                    {
                        case 1: //free calls
                            int tmpMinL=9000,tmpMinM=9001; //for Landline and Mobile
                            int tmpMaxL=-1,tmpMaxM=-2; 
                            int tmpSumL=0,tmpSumM=0; //i don`t take same values to be easier on debug
                            int sizeL=0,sizeM=0;
                             for(int i=0; i<listOfCustomers.size();i++)
                             { 
                                for(int j=0;j<listOfCustomers.get(i).listOfContracts.size();j++)
                                {    
                                    //calculate min,max,mean
                                   //for Landline  
                                    int freeCalls=listOfCustomers.get(i).listOfContracts.get(j).getMinsOfFreeCalls();
                                   if(listOfCustomers.get(i).listOfContracts.get(j).getPhone().toString().startsWith("2")) 
                                   {
                                       //calculate min
                                      tmpMinL=findMin(tmpMinL,freeCalls);
                                      //calculate max
                                      tmpMaxL=findMax(tmpMaxL,freeCalls);
                                      //calculate mean
                                      tmpSumL+=freeCalls;
                                      sizeL++;
                                   }else{//so its mobile
                                       //calculate Min
                                       tmpMinM=findMin(tmpMinM,freeCalls);
                                       //Calculate Max
                                       tmpMaxM=findMax(tmpMaxM,freeCalls);
                                       //calculate mean
                                       tmpSumM+=freeCalls;
                                      sizeM++;
                                   }
                                }
                             }
                             float meanL,meanM;
                             meanL=(float)(tmpSumL)/(float)(sizeL);
                             meanM=(float)(tmpSumM)/(float)(sizeM);
                               
                             System.out.println("Landlines statistics for free calls\n"
                                        + "\tMin\tMax\tMean\n\t"+
                                        +tmpMinL+"\t"+tmpMaxL+ "\t" +meanL +"\n");  
                             
                             System.out.println("Mobiles statistics for free calls \n"
                                        + "\tMin\tMax\tMean\n\t"+
                                        +tmpMinM+"\t"+tmpMaxM+ "\t" +meanM +"\n");      
                        break;
                        
                        case 2: //sms
                          tmpMinM=9000;
                           tmpMaxM=-1;
                           tmpSumM=0;
                           sizeM=0;
                           
                             for(int i=0; i<listOfCustomers.size();i++)
                             {   
                                 int sms=0;
                                  for(Contract cont: listOfCustomers.get(i).listOfContracts){
                                      if (cont instanceof Mobile)
                                      {
                                      Mobile mob = (Mobile)cont;
                                       sms=mob.getSumOfFreeSMS();
                                          //calculate min
                                      tmpMinM=findMin(tmpMinM,sms);
                                      //calculate max
                                      tmpMaxM=findMax(tmpMaxM,sms);
                                      //calculate mean
                                      tmpSumM+=sms;
                                      sizeM++;
                                      }        
                                  }
                            }
                             meanM=(float)(tmpSumM)/(float)(sizeM);
                            
                             System.out.println("Mobile statistics for SMS\n"
                                        + "\tMin\tMax\tMean\n\t"+
                                        +tmpMinM+"\t"+tmpMaxM+ "\t" +meanM +"\n");  
                             
                             
                         break;
                                      
                              
                        case 3: //MB
                           tmpMinM=9000;
                           tmpMaxM=-1;
                           tmpSumM=0;
                           sizeM=0;
                             for(int i=0; i<listOfCustomers.size();i++)
                             {   
                                 int mb=0;
                                  for(Contract cont: listOfCustomers.get(i).listOfContracts){
                                      if (cont instanceof Mobile)
                                      {
                                      Mobile mob = (Mobile)cont;
                                      mb=mob.getSumOfFreeMB();
                                          //calculate min
                                      tmpMinM=findMin(tmpMinM,mb);
                                      //calculate max
                                      tmpMaxM=findMax(tmpMaxM,mb);
                                      //calculate mean
                                      tmpSumM+=mb;
                                      sizeM++;
                                      }        
                                  }
                            }
                             meanM=(float)(tmpSumM)/(float)(sizeM);
                             System.out.println("Mobile statistics for MB\n"
                                        + "\tMin\tMax\tMean\n\t"+
                                        +tmpMinM+"\t"+tmpMaxM+ "\t" +meanM +"\n");   
                         break;
                         
                        default:
                            System.out.println("Something went wrong!");
                        break;
                                   
                    }
              break;
            case 2://see details of contracts
                     System.out.println("\tGive me your vat");
                     int vat=y.nextInt();
                     while(vat<=99999999 || vat>999999999){ //so  8 or 10 digit number given
                        System.out.println("\tCheck it again!Remember its an 9-digit number ");
                        vat = y.nextInt();
                      }
                     cust=findCustomer(vat);
                             if(cust==null){
                                 System.out.println("\twe didn`t find any customer!");
                                 return;
                             }
                     System.out.println("\nnumber phone      type     startDate            duration");
                     for(int index=1;index<cust.listOfContracts.size()+1 ;index++){
                           if ("mobile".equals(printType(cust.listOfContracts.get(index-1).getPhone())))
                            System.out.println("  "+index+"    "+cust.listOfContracts.get(index-1).getPhone()+" "+ printType(cust.listOfContracts.get(index-1).getPhone())+"   "+cust.listOfContracts.get(index-1).getLdt()+"  "+printDuration(cust.listOfContracts.get(index-1).getDuration()));   
                           if ("landline".equals(printType(cust.listOfContracts.get(index-1).getPhone())))
                            System.out.println("  "+index+"    "+cust.listOfContracts.get(index-1).getPhone()+" "+ printType(cust.listOfContracts.get(index-1).getPhone())+" "+cust.listOfContracts.get(index-1).getLdt()+"  "+printDuration(cust.listOfContracts.get(index-1).getDuration()));    
                      }
                   break;
                   
                case 3:
                     //see discound
                    System.out.println("\tgive me your vat");
                    int vatt=y.nextInt();
                     while(vatt<=99999999 || vatt>999999999){ //so  8 or 10 digit number given
                        System.out.println("\tCheck it again!Remember its an 9-digit number ");
                        vatt = y.nextInt();
                      }
                     cust=findCustomer(vatt);
                      if(cust==null){
                            System.out.println("\twe didn`t find any customer!");
                            return;
                        }
                     int totalDiscounds=0;
                     int tmp=0;
                     for(int i=0;i<cust.listOfContracts.size() ;i++){
                        if(cust.listOfContracts.get(i).getLdt().isBefore(LocalDateTime.now())|| cust.listOfContracts.get(i).getLdt().plusMonths(cust.listOfContracts.get(i).getDuration()).isAfter(LocalDateTime.now())){
                            totalDiscounds+= totalDiscounds(cust,i,0);
                             //we don`t want take them more than one time, is for all contracts
                             tmp=cust.listOfContracts.get(i).getDiscoundsPerContract()+cust.listOfContracts.get(i).getDiscoundsStatus() ;
                         }
                    }
                          totalDiscounds+=tmp;
                          if(totalDiscounds>45) totalDiscounds=45;
                          System.out.println("your  contract has  total discound:"+totalDiscounds+"%");
                     break;
                default:
                    System.out.println("\tSomething went really wrong!");
                    break;
       }
    }

   
    
    //STATISTICS
     private int findMin(int number1,int number2)
     {
         if(number1<number2) 
             return number1;
         else 
             return number2;
     }
    
    private int findMax(int number1,int number2)
     {
         if(number1>number2) 
             return number1;
         else 
             return number2;
     }
    
    //DISCOUNDS
   private int discoundsByContract(Customer c)
   {
      //for each contract
      int sum=0;
        for(int i=0;i<c.listOfContracts.size() ;i++){
               //an auto pou edwse gia arxh einai prin apo thn shmerinh hmeromhnia 
               if(c.listOfContracts.get(i).getLdt().isBefore(LocalDateTime.now())){
                   //kai to telos = duration+arxh einai meta apo thn shmerinh
                   if(c.listOfContracts.get(i).getLdt().plusMonths(c.listOfContracts.get(i).getDuration()).isAfter(LocalDateTime.now())){
                      //tote eisai entos oriwn ... sta energa sumbolaia 
                       sum++; //sum of contracs
                       //set discounds status using method discoundsStatus
                       c.listOfContracts.get(i).setDiscoundsStatus(discoundsStatus(c.getCustomerStatus()));
                       //set discounds  free calls using method discoundsFreeCalls
                       c.listOfContracts.get(i).setDiscoundsFreeCalls(discoundsFreeCalls(c,i));
                        //set discounds payment  using method discoundsPayment
                       c.listOfContracts.get(i).setDisoundsPayment(discoundsPayment(i,c.listOfContracts.get(i).getMethodOfPayment(),c));
                       //set discounds E-Account using discoundsEAccount method
                       c.listOfContracts.get(i).setDiscoundsEAccount(discoundsEAccount(c,i));
                   }
               }
            }
        if (sum>=3) return 15;
        if (sum==2) return 10;
        if (sum==1) return 5;
        return 0;
   }
   
    private int discoundsStatus(int i){
        if(i==1) return 15;//student
        if(i==3) return 10;//Professional
        return 0;
    }
    
    private int discoundsPayment(int i,int j,Customer c){
        if(j==1||j==3) return 5; //credit card or bank account
        return 0;
    }
    
    private int discoundsEAccount(Customer c,int i){
        if(c.listOfContracts.get(i).geteAccountOrNot()==1) return 2;// has e account
        return 0;
    }
    
    private int discoundsFreeCalls(Customer c,int i){
        if(c.listOfContracts.get(i).getMinsOfFreeCalls() >= 1000){
          if(c.listOfContracts.get(i).getPhone().toString().startsWith("2")) return 8;
          if(c.listOfContracts.get(i).getPhone().toString().startsWith("6")) return 11;
        }
        return 0;
    }
    
    private int totalDiscounds(Customer c,int i,int total){
    //    System.out.println("discoundsByContract");
        int discound =discoundsByContract(c);
        c.listOfContracts.get(i).setDiscoundsPerContract(discound);
        total=c.listOfContracts.get(i).getDiscoundsFreeCalls()+c.listOfContracts.get(i).getDisoundsPayment()+c.listOfContracts.get(i).getDiscoundsEAccount();      
        return total; 
    }
          
     
     ///PRINTERS  
     
     //HELP TO PRINT TYPE OF CONTRACT
     private String printType(BigInteger b){
         if(b.toString().startsWith("69")) return "mobile";
         if(b.toString().startsWith("2")) return "landline";
         return "something went wrong with type printer";
     }
     
     //HELP TO PRINT STATUS OF CUSTOMER TO CONTRACT
     private String printStatus(int i){
        if(i==1) return "Student";
        if(i==2) return "Individual";//Ιδιώτης
        if(i==3) return "Professional";
        return "something went wrong with status printer";
    }
    
     //HELP TO PRINT ADSL OR VDSL OPTION IN CONTRACT
    private String printAdslOrVdsl(int i){
        if(i==1) return "ADSL";
        if(i==2) return "VDSL";
        return"something went wrong with adsl or vdsl printer";
    }
    
    //HELP TO PRINT METHOD OF PAYMENT THAT CUSTOMER WANTS TO, ON CONTRACT
    private String printMethodOfPayment(int i){
        if(i==1) return "credit card";//pistwtikh
        if(i==2) return "cash"; //metrhta
        if(i==3) return "bank account"; //mesw trapezas 
        return "something went wrong with method payment printer";
    }
    
    //HELP TO PRINT DURATION OF CONTRACT
    private String printDuration(int i){
        if(i==24) return "24 months";
        if(i==12) return "12 months";
        return "something went wrong with duration printer";
    }
    
    //HELP OT PRINT IF CUSTOMER WANTS E ACCOUNT OR NOT
      private String printEAccount(int i){
        if(i==1) return "yes";
        if(i==0) return "no";
        return "something went wrong with e-account printer";
    }   

      
     
}
        