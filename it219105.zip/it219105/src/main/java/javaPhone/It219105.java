/*
 * This class has a main method.
 * Made to help execute-run the project.
 * Includes menu-option, and for each calls the appropriate method.
*/

package javaPhone;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *                  
 * @author meletis tsesmelis (it219105)
 */
public class It219105 {
    public static void main(String args[]) {
        
        System.out.println("\t\tHello there!Welcome to my app!");
        
        Methods y = new Methods();
        y.myCustomers();
        boolean run=true;
        while(run){
        y.menu();
        Scanner x = new Scanner(System.in);
         int answer=0 ;
         
        try{
             answer = x.nextInt();
        }catch(InputMismatchException e){
            System.out.println("\tOh maybe I get sick with covid-19 :( ...Or you pressed an unexpected type!\n\tI am going to add antivirus!Aborting...");
            return;
        }
        
        /*
         * To run option 3 or 4 without use 1 and 2 option you have to take a look on class Methods.
         * I have there by default customers so you can use them.To be easier for you i will write one.
         *          One of them has VAT:123456789. 
         * He has 2 contracts, he is professional.
         * He has a  packet on mobile contract with: 1200min for calls, 100sms, 20000mb -> payment:cash, eAccount: yes
         * He has a packe on landline contract with: 1800min for calls ->payment: bank, eAccount: yes
         *
        */
          try{
              switch (answer) 
            {
                case 1: //add profile
                    y.toImportCustomerProfile();
                   break;
                case 2://add contract
                    y.toIntroductionNewContract();
                   break;
                case 3://delete contract
                    y.toDeleteContract();
                    break;
                case 4:
                    /*see statistics of contracts, and option to see his 
                      contracts and their information*/
                    y.toSeeStatisticsOfActiveContracts();
                    break;
                case 5://exit
                    System.out.println("\t\tHave a nice day!");
                    run=false;
                    break;
                default:
                    System.out.println("\tNo option for this number!I am sure that your number is close...stay focused and try again!");
                    break;         
                  }
          }catch(InputMismatchException e){
              System.out.println("\tUnexpected type of input!Sorry but I have to abort...let`s go on menu!");
          }
        }
    }
}
