/*
 * This class made to save informations of  a profile. 
 * Initialize variables and infomarions that a customer needs.
 * 
*/
package javaPhone;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author meletis tsesmelis (it219105)
 */
public class Customer {

    //initialize variables
    private int vat;
    private String customerAddress;
    private int identity;
    private int customerStatus;

    private int customerID;
    private String email;

    Random rdm = new Random();

    
    //make getters and setters
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    //make an array list with contracts
    public ArrayList<Contract> listOfContracts;
 
   //make a contructor, make an contract list for this customer
    public Customer() {
        this.listOfContracts = new ArrayList<>();
    }

    //make a contructor to take informations of customer
    public Customer(int vat, String address, int identity, int status, String email) {
        this.listOfContracts = new ArrayList<>();
        this.vat = vat;
        this.customerAddress = address;
        this.identity = identity;
        this.customerStatus = status;
        this.customerID = rdm.nextInt();
        this.email = email;
    }

    //continue the setter getters create
    public int getVAT() {
        return vat;
    }

    public void setVAT(int vat) {
        this.vat = vat;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public int getIdentity() {
        return identity;
    }

    public void setIdentity(int identity) {
        this.identity = identity;
    }

    public int getCustomerStatus() {
        return customerStatus;
    }

    public void setCustomerStatus(int customerStatus) {
        this.customerStatus = customerStatus;
    }

    public int getIdCustomer() {
        return customerID;
    }

    public void setCustomerID() {
        this.customerID = rdm.nextInt(100);//so put random number with seed the time of system;
    }

}
